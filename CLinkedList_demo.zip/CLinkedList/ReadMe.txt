========================================================================
    CONSOLE APPLICATION : CLinkedList Project Overview
========================================================================

PLEASE NOTE THAT THE OUTPUT OF THIS PROGRAM is contained below.

Property Pages:
C/C++->Preprocessor->_CRT_SECURE_NO_WARNINGS
Linker->System->Stack Resere Size: 	8000000

I have used the above Project MACROS to enable the use of strcpy(), strcmp, etc.
I have also increased Stack size even though all data nodes are allocated on the heap.
The values of your doubles in test 3 will be different every time you run the program.

CLinkedList.vcxproj
    This is the main project file for VC++ projects generated using an Application Wizard.
    It contains information about the version of Visual C++ that generated the file, and
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

CLinkedList.vcxproj.filters
    This is the filters file for VC++ projects generated using an Application Wizard. 
    It contains information about the association between the files in your project 
    and the filters. This association is used in the IDE to show grouping of files with
    similar extensions under a specific node (for e.g. ".cpp" files are associated with the
    "Source Files" filter).

CLinkedList.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named CLinkedList.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Output:

Now demonstrating the find functionality of the CLinkedList
This is effectively a sequential search of the CLinkedList class
All searches use the data comparison routine YOU designate
Looking for node containing >DATA=05<
(RETURN to continue)


Found >DATA=05< myChar=05 Position=(5)
We may also use a binary search (obviously quicker) on a sorted list
In order to find a node.  This time, we use the dlbsearch() method
Looking for node >DATA=06< with dlbsearch()
Found >DATA=06< myChar=06 Position=(6)
Press RETURN to continue
Adding another node to the list
Adding Data=>DATA=00< myChar=00
There are currently 11 nodes in the list
>DATA=01< myChar=01 Position=(1)
>DATA=02< myChar=02 Position=(2)
>DATA=03< myChar=03 Position=(3)
>DATA=04< myChar=04 Position=(4)
>DATA=05< myChar=05 Position=(5)
>DATA=06< myChar=06 Position=(6)
>DATA=07< myChar=07 Position=(7)
>DATA=08< myChar=08 Position=(8)
>DATA=09< myChar=09 Position=(9)
>DATA=10< myChar=10 Position=(10)
>DATA=00< myChar=00 Position=(11)
Press RETURN to continue
When adding to the list, using the dladd() method appends to the
end of the list
The List is now NOT correctly sorted, so we try a dlbsearch() on the
list.  We should now expect a FAIL because a binary search only works on a sorte
d list.
Couldn't find it! - Status = 5
This is the error number >ListHasNotBeenSorted< or
We now sort the list with dlqsort() and try again
RETURN to continue and sort


List has now been sorted by the qsort() method
Looking again for DATA=06
(RETURN to continue)

Found >DATA=06< myChar=06 Position=(7)
Printing the list again (forwards)

>DATA=00< myChar=00 Position=(1)
>DATA=01< myChar=01 Position=(2)
>DATA=02< myChar=02 Position=(3)
>DATA=03< myChar=03 Position=(4)
>DATA=04< myChar=04 Position=(5)
>DATA=05< myChar=05 Position=(6)
>DATA=06< myChar=06 Position=(7)
>DATA=07< myChar=07 Position=(8)
>DATA=08< myChar=08 Position=(9)
>DATA=09< myChar=09 Position=(10)
>DATA=10< myChar=10 Position=(11)
Press RETURN to continue

About to CHANGE the comparison function using dlsetcompare()
sorting will also occur (different comparison function)
Finished - About to print list contents (RETURN to continue)

>DATA=10< myChar=10 Position=(1)
>DATA=09< myChar=09 Position=(2)
>DATA=08< myChar=08 Position=(3)
>DATA=07< myChar=07 Position=(4)
>DATA=06< myChar=06 Position=(5)
>DATA=05< myChar=05 Position=(6)
>DATA=04< myChar=04 Position=(7)
>DATA=03< myChar=03 Position=(8)
>DATA=02< myChar=02 Position=(9)
>DATA=01< myChar=01 Position=(10)
>DATA=00< myChar=00 Position=(11)
Note how the nodes are now sorted in DESCENDING order
About to delete NODE 6 (RETURN to continue)


FreeData: deleting string >06<
DONE!.. about to print list contents
>DATA=10< myChar=10 Position=(1)
>DATA=09< myChar=09 Position=(2)
>DATA=08< myChar=08 Position=(3)
>DATA=07< myChar=07 Position=(4)
>DATA=05< myChar=05 Position=(5)
>DATA=04< myChar=04 Position=(6)
>DATA=03< myChar=03 Position=(7)
>DATA=02< myChar=02 Position=(8)
>DATA=01< myChar=01 Position=(9)
>DATA=00< myChar=00 Position=(10)
There are now 10 nodes in the list
(RETURN to continue)

About to insert a NODE at BEGINNING of LIST (RETURN to continue)

sizeof(myStructure.Data)=(80)

After dlinsert.......
>NODE=This is the NEWLY dlinserted one!< myChar=Inserted Number Position=(1)
>DATA=10< myChar=10 Position=(2)
>DATA=09< myChar=09 Position=(3)
>DATA=08< myChar=08 Position=(4)
>DATA=07< myChar=07 Position=(5)
>DATA=05< myChar=05 Position=(6)
>DATA=04< myChar=04 Position=(7)
>DATA=03< myChar=03 Position=(8)
>DATA=02< myChar=02 Position=(9)
>DATA=01< myChar=01 Position=(10)
>DATA=00< myChar=00 Position=(11)
There are now 11 nodes in the list

About to replace <DATA=10> with <DATA=11>
(RETURN to continue)
Searching for DATA=10
SUCCESSFUL find
FreeData: deleting string >10<
>NODE=This is the NEWLY dlinserted one!< myChar=Inserted Number Position=(1)
>DATA=11< myChar=Now Number 11 Position=(2)
>DATA=09< myChar=09 Position=(3)
>DATA=08< myChar=08 Position=(4)
>DATA=07< myChar=07 Position=(5)
>DATA=05< myChar=05 Position=(6)
>DATA=04< myChar=04 Position=(7)
>DATA=03< myChar=03 Position=(8)
>DATA=02< myChar=02 Position=(9)
>DATA=01< myChar=01 Position=(10)
>DATA=00< myChar=00 Position=(11)
There are now 11 nodes in the list
About to test list marking methods (any key to continue)

As there have been no previously MARKED nodes in the list
we WILL get an error code of NodeNotPreviouslyMarked returned
ERROR: (expected) Not previously marked!
ERROR: (expected) Node has NOT been marked!
(RETURN to continue)

About to mark the third node in the list
(RETURN to continue)
Done. Marked node :DATA=03
Moving away from marked node:
Done. now at node (11)
Searching for previously marked node
OK, at the marked node
>DATA=03< myChar=03 Position=(8)
The size of each NODE in the list is(84) bytes
Looking for list element [0]
(RETURN to continue)

Found: >NODE=This is the NEWLY dlinserted one!< myChar=Inserted Number Position=
(1)
About to dump list contents...
(RETURN to continue)

Dumping list contents:
Dump <Dumping List Contents: 1> begins - length = 84
000:000: 4e4f4445 3d546869 73206973 20746865 >NODE=This is the<
016:010: 204e4557 4c592064 6c696e73 65727465 > NEWLY dlinserte<
032:020: 64206f6e 652100cc cccccccc cccccccc >d one!..........<
048:030: cccccccc cccccccc cccccccc cccccccc >................<
064:040: cccccccc cccccccc cccccccc cccccccc >................<
080:050: d09aac00                            >....            <
Dump <Dumping List Contents: 1> Ends
Dump <Dumping List Contents: 2> begins - length = 84
000:000: 44415441 3d313100 73206973 20746865 >DATA=11.s is the<
016:010: 204e4557 4c592064 6c696e73 65727465 > NEWLY dlinserte<
032:020: 64206f6e 652100cc cccccccc cccccccc >d one!..........<
048:030: cccccccc cccccccc cccccccc cccccccc >................<
064:040: cccccccc cccccccc cccccccc cccccccc >................<
080:050: 50a1ac00                            >P...            <
Dump <Dumping List Contents: 2> Ends
Dump <Dumping List Contents: 3> begins - length = 84
000:000: 44415441 3d303900 cccccccc cccccccc >DATA=09.........<
016:010: cccccccc cccccccc cccccccc cccccccc >................<
032:020: cccccccc cccccccc cccccccc cccccccc >................<
048:030: cccccccc cccccccc cccccccc cccccccc >................<
064:040: cccccccc cccccccc cccccccc cccccccc >................<
080:050: 5097ac00                            >P...            <
Dump <Dumping List Contents: 3> Ends
Dump <Dumping List Contents: 4> begins - length = 84
000:000: 44415441 3d303800 cccccccc cccccccc >DATA=08.........<
016:010: cccccccc cccccccc cccccccc cccccccc >................<
032:020: cccccccc cccccccc cccccccc cccccccc >................<
048:030: cccccccc cccccccc cccccccc cccccccc >................<
064:040: cccccccc cccccccc cccccccc cccccccc >................<
080:050: 5098ac00                            >P...            <
Dump <Dumping List Contents: 4> Ends
Dump <Dumping List Contents: 5> begins - length = 84
000:000: 44415441 3d303700 cccccccc cccccccc >DATA=07.........<
016:010: cccccccc cccccccc cccccccc cccccccc >................<
032:020: cccccccc cccccccc cccccccc cccccccc >................<
048:030: cccccccc cccccccc cccccccc cccccccc >................<
064:040: cccccccc cccccccc cccccccc cccccccc >................<
080:050: 5099ac00                            >P...            <
Dump <Dumping List Contents: 5> Ends
Dump <Dumping List Contents: 6> begins - length = 84
000:000: 44415441 3d303500 cccccccc cccccccc >DATA=05.........<
016:010: cccccccc cccccccc cccccccc cccccccc >................<
032:020: cccccccc cccccccc cccccccc cccccccc >................<
048:030: cccccccc cccccccc cccccccc cccccccc >................<
064:040: cccccccc cccccccc cccccccc cccccccc >................<
080:050: 509bac00                            >P...            <
Dump <Dumping List Contents: 6> Ends
Dump <Dumping List Contents: 7> begins - length = 84
000:000: 44415441 3d303400 cccccccc cccccccc >DATA=04.........<
016:010: cccccccc cccccccc cccccccc cccccccc >................<
032:020: cccccccc cccccccc cccccccc cccccccc >................<
048:030: cccccccc cccccccc cccccccc cccccccc >................<
064:040: cccccccc cccccccc cccccccc cccccccc >................<
080:050: 509cac00                            >P...            <
Dump <Dumping List Contents: 7> Ends
Dump <Dumping List Contents: 8> begins - length = 84
000:000: 44415441 3d303300 cccccccc cccccccc >DATA=03.........<
016:010: cccccccc cccccccc cccccccc cccccccc >................<
032:020: cccccccc cccccccc cccccccc cccccccc >................<
048:030: cccccccc cccccccc cccccccc cccccccc >................<
064:040: cccccccc cccccccc cccccccc cccccccc >................<
080:050: 509dac00                            >P...            <
Dump <Dumping List Contents: 8> Ends
Dump <Dumping List Contents: 9> begins - length = 84
000:000: 44415441 3d303200 cccccccc cccccccc >DATA=02.........<
016:010: cccccccc cccccccc cccccccc cccccccc >................<
032:020: cccccccc cccccccc cccccccc cccccccc >................<
048:030: cccccccc cccccccc cccccccc cccccccc >................<
064:040: cccccccc cccccccc cccccccc cccccccc >................<
080:050: 509eac00                            >P...            <
Dump <Dumping List Contents: 9> Ends
Dump <Dumping List Contents: 10> begins - length = 84
000:000: 44415441 3d303100 cccccccc cccccccc >DATA=01.........<
016:010: cccccccc cccccccc cccccccc cccccccc >................<
032:020: cccccccc cccccccc cccccccc cccccccc >................<
048:030: cccccccc cccccccc cccccccc cccccccc >................<
064:040: cccccccc cccccccc cccccccc cccccccc >................<
080:050: 509fac00                            >P...            <
Dump <Dumping List Contents: 10> Ends
Dump <Dumping List Contents: 11> begins - length = 84
000:000: 44415441 3d303000 cccccccc cccccccc >DATA=00.........<
016:010: cccccccc cccccccc cccccccc cccccccc >................<
032:020: cccccccc cccccccc cccccccc cccccccc >................<
048:030: cccccccc cccccccc cccccccc cccccccc >................<
064:040: cccccccc cccccccc cccccccc cccccccc >................<
080:050: 50a0ac00                            >P...            <
Dump <Dumping List Contents: 11> Ends
FreeData: deleting string >Inserted Number<
FreeData: deleting string >Now Number 11<
FreeData: deleting string >09<
FreeData: deleting string >08<
FreeData: deleting string >07<
FreeData: deleting string >05<
FreeData: deleting string >04<
FreeData: deleting string >03<
FreeData: deleting string >02<
FreeData: deleting string >01<
FreeData: deleting string >00<
There are (0) nodes in the list
List test 1 complete ...

Testing atomic data types...
Nodes in list = (10)
Value = (10): posn = (1)
Value = (9): posn = (2)
Value = (8): posn = (3)
Value = (7): posn = (4)
Value = (6): posn = (5)
Value = (5): posn = (6)
Value = (4): posn = (7)
Value = (3): posn = (8)
Value = (2): posn = (9)
Value = (1): posn = (10)
List test 2 complete ... <press <ENTER>

Adding (0.169012) to the list
Adding (0.405072) to the list
Adding (0.961394) to the list
Adding (0.14716) to the list
Adding (0.581713) to the list
Adding (0.133793) to the list
Adding (0.915708) to the list
Adding (0.739341) to the list
Adding (0.808863) to the list
Adding (0.333995) to the list
Nodes in list = (10)

Printing list of doubles AFTER insertion sorting...
Value = (0.133793): posn = (1)
Value = (0.14716): posn = (2)
Value = (0.169012): posn = (3)
Value = (0.333995): posn = (4)
Value = (0.405072): posn = (5)
Value = (0.581713): posn = (6)
Value = (0.739341): posn = (7)
Value = (0.808863): posn = (8)
Value = (0.915708): posn = (9)
Value = (0.961394): posn = (10)
List test 3 complete ... <press <ENTER>


C:\Projects\CLinkedList\Debug\CLinkedList.exe (process 3568) exited with code 0.

Press any key to close this window . . .
/////////////////////////////////////////////////////////////////////////////
