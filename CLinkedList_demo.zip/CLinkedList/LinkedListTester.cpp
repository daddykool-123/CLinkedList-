// LinkedListTester.cpp : Defines the entry point for the console application.
//

// This demonstrates a linked list of any data type up to and including structures.
//
// As the data is stored separately from the node in a list, said data is stored
// in memory as it's allocated (heap).  Therefore heavy use of typecasting pointers 
// is required. 
// As you can see below, I've quite created a bit of reading and I should have
// created more funtions to do this task.
// However, I've done this deliberately so you can see how pointers are easy to use
// with this code.  The "slab" of code as well as the output of the program are
// intended to complement each other as an educational tool.
//
// ---------------- Module include files -------------------------------
#include "stdafx.h"

#include "LinkedList.h"	// Linked list funtionality.
using namespace std;

// ---------------- Module constant definitions ------------------------

const int	kMaxNodes = 10;		// Number of nodes for this demonstration.
const int	kSmallBuf = 80;		// Scratch buffer sizes.

// ---------------- Module typedef statements --------------------------

typedef struct {					// This can be ANY defined structure.
	char Data[kSmallBuf];
	char *myChar;					// Used to illustrate the FreeData function.
}
Structure;

// NOTES:
// The functions "NormalStringCompare and "ReverseStringCompare" below are used to demonstrate the 
// "SetCompare function in the linked list routines.  As well as comparison,
// these finctions are also used by the list dlfind(), dlqsort() and dlsort()
// routines. In this case, it is assumed that the objects to be compared are 
// character arrays or "strings".

// ---------------- Module function definitions begin here -------------

/******************************************************************************
*  Function Name: NormalStringCompare()
*
*  Purpose:This is a user defined comparison function used by the linked list
*			functions dlfind(), dlqsort() and dlsort().
*
*  Parameters:    Two structures to be compared.
*
*  Side Effects:  None.
*
*  Return Values: The result of strcmp().
*
*  Notes:
*		1.	In this case, the "key" used is the char "Data" field of the
*			user's STRUCTURE.
*		2.	This function compares d1 against d2.(NORMAL LEXICOGRAPHICAL COMPARE)
*		3.	Used to test the comparison "change" function dlsetcompare();
*
******************************************************************************/
int NormalStringCompare(const void* d1, const void *d2)
{
	Structure	*s1 = (Structure *)d1;
	Structure	*s2 = (Structure *)d2;

	return strcmp((char *)s1->Data, (char *)s2->Data);
}
/******************************************************************************
*  Function Name: ReverseStringCompare()
*
*  Purpose:This is a user defined comparison function used by the linked list
*			functions dlfind(), dlqsort() and dlsort().
*
*  Parameters:    Two structures to be compared.
*
*  Side Effects:  None.
*
*  Return Values: The result of strcmp().
*
*  Notes:
*		1.	In this case, the "key" used is the char "Data" field of the
*			user's STRUCTURE.
*		2.	This function compares d2 against d1. (REVERSE COMPARE )
*		3.	Used to test the comparison "change" function dlsetcompare();
******************************************************************************/
int ReverseStringCompare(const void *d1, const void *d2)
{
	Structure	*s1 = (Structure *)d2;	// Opposite of Compare1()
	Structure	*s2 = (Structure *)d1;	// ditto

	return strcmp((char *)s1->Data, (char *)s2->Data);
}
/******************************************************************************
*  Function Name: CompareIntegers()
*
*  Purpose:This is a user defined comparison function used by the linked list
*			functions dlfind(), dlqsort() and dlsort(). It is used to exemplify
*			the use of lists with atomic dta types.
*
*  Parameters:		Two integers to be compared.
*
*  Side Effects:	None.
*
*  Return Values:	0 or 1 or -1.
*
*  Notes:			Used ONLY for comparing 2 integers.
*
*
******************************************************************************/
int CompareIntegers(const void *d1, const void *d2)
{
	int int_1 = *(int *)d1;
	int int_2 = *(int *)d2;
	int retCode = 0;

	if (int_1 == int_2)
		retCode = 0;
	else if (int_1 < int_2)
		retCode = -1;
	else if (int_1 > int_2)
		retCode = 1;

	return (retCode);
}

/******************************************************************************
*  Function Name: FreeData()
*
*  Purpose: A Cleanup function.
*		This user defined function removes any other "items" connected to the
*		linked list. For example, the structure defined may have other linked
*		lists or "allocated" nodes that need to be freed before the actual
*		linked list is removed from memory.  In the example STRUCTURE, a char
*		pointer myChar  has had memory allocated and a value inserted. This
*		function frees the previously allocated space back to memory as part
*		of the list's destructor, just prior to deleting the linked list.
*
*  Parameters: The incoming void pointer which is currently pointing at the
*		user defined STRUCTURE structure.
*
*  Side Effects:  Memory is released back to the system.
*
*  Return Values: None (in this case).
*
*  Notes:
*		1.	In this case, the "key" used is the char "Data" field
*			of the user's STRUCTURE.
*
******************************************************************************/
void FreeData(void *p)
{
	Structure	*pStructure = (Structure *)p;
	if ( p ) {
		cout << "FreeData: deleting string >" << pStructure->myChar << "<" << endl;
		delete[] pStructure->myChar;
	}
}

/******************************************************************************
*  Function Name: int TestLinkedListRoutinesWithStructures(void)
*
*  Purpose:
*		Demonstrates just about all of the CLinkedList class member functions
*		using a simple structure.
*
*  Parameters: None.
*
*  Side Effects:  None.
*
*
*  Notes:
*		1.	My apologies to those who already know that this function is too long. I
*			decided to include it at the last minute, so that you can see for
*			yourself that the functionality does indeed work.
*
*
******************************************************************************/
int TestLinkedListRoutinesWithStructures(void)
{
	// Greet the user first
	cout << "Hello..." << endl;

	Structure	myStructure;			// A user defined structure.
	Structure	*pStructure;			// Pointer to a user defined structure.
	int			retCode = -1;

	CLinkedList  myList(sizeof(Structure), NormalStringCompare, FreeData);

	//-----Examples of alternate calling method (No cleanup function) --------
	// CLinkedList	myList2(sizeof(Structure), ReverseStringCompare);
	//-----------------------------------------------------*/
	cout << "List Initialisation status = "
		<< (myList.GetStatus() == 0 ? "Successful" : "Fail");
	/**************************************************************************
	*  Add some test elements to the list
	*	Start from high numbers to low ones.
	*************************************************************************/
	cout << endl << "List Successfully created" << endl;
	cout << "ADDING (" << kMaxNodes << ") nodes in descending order with insertion sort" << endl;

	for (int i = kMaxNodes; i > 0; i--) {
	
		// Populate our structure with some useful information.
		sprintf(myStructure.Data, "DATA=%02d", i);
		// allocate some memory for the char pointer
		myStructure.myChar = new char[kSmallBuf];

		assert(myStructure.myChar);
		// print a number into the new space
		sprintf(myStructure.myChar,  "%02d", i);
		cout << "Adding Data=>" << myStructure.Data << "< myChar="
			<< myStructure.myChar << endl;
		// Add the new node to the list
		if ((retCode = myList.dladdins(&myStructure)) != 0) {
			cout << "Error " << retCode << " Adding to list" << endl;
			return (retCode);
		}
	}
	cout << "There are: " << myList.dlcount() << " Nodes in the list." << endl;
	cout << "Notice that we have inserted nodes in descending order." << endl;
	cout << "Because we have specified dladdins, we have forced the" << endl;
	cout << "nodes in the list to be sorted on insert. YOUR comparison" << endl;
	cout << "was used on list creation and insertion" << endl;
	cout << "Press RETURN to continue";
	getchar();
	/*-------------------------------------------------------
	* Now traverse the list from start to end and print
	* out the contents of each structure in the list.
	*------------------------------------------------------*/
	cout << endl << "Printing list nodes from BEGIN to END of list" << endl;
	pStructure = (Structure *)myList.dltofirst();

	while (pStructure) {
		cout << ">" << pStructure->Data << "< myChar=" << pStructure->myChar
			<< " Position=(" << myList.dlposn() << ")" << endl;
		pStructure = (Structure *)myList.dlgofwd();
	}
	cout << "Finished - About to traverse backwards... " << endl;
	cout << "Press RETURN to continue";
	getchar();

	/*-------------------------------------------------------
	*      Now do the same from end to beginning of list.
	*------------------------------------------------------*/
	cout << "Printing list nodes from END to BEGIN of list" << endl;pStructure = (Structure *)myList.dltolast();
	while (pStructure) {
		cout << ">" << pStructure->Data << "< myChar=" << pStructure->myChar
			<< " Position=(" << myList.dlposn() << ")" << endl;
		pStructure = (Structure *)myList.dlgoback();
	}
	cout << endl;
	cout << "Press RETURN to continue";
	getchar();

	/*-------------------------------------------------------
	* Now traverse the list from start to end AGAIN and print
	* out the contents of each structure in the list.
	* This time we use some of the overloaded operators.
	*------------------------------------------------------*/
	cout << endl << "Printing list nodes AGAIN from BEGIN to END of list" << endl;
	cout << "This time using overloaded operators ++ and -- to achieve the same result" << endl;

	pStructure = (Structure *)myList[0];
	while (pStructure) {
		cout << ">" << pStructure->Data << "< myChar=" << pStructure->myChar
			<< " Position=(" << myList.dlposn() << ")" << endl;
		pStructure = (Structure *)myList++;
	}

	cout << "Finished - About to traverse backwards... " << endl;
	cout << "There are currently " << myList.dlcount() << " nodes in the list" << endl;
	cout << "Press RETURN to continue";
	getchar();
	cout << endl;

	pStructure = (Structure *)myList[myList.dlcount() - 1];
	while (pStructure) {
		cout << ">" << pStructure->Data << "< myChar=" << pStructure->myChar
			<< " Position=(" << myList.dlposn() << ")" << endl;
		pStructure = (Structure *)myList--;
	}

	cout << "Press RETURN to continue";
	getchar();
	cout << endl;
	/*-------------------------------------------------------
	* Now we search for a particular node in the list. A
	* NULL pointer is returned ( by CLinkedList) if we can't find it
	*------------------------------------------------------*/
	cout << "Now demonstrating the find functionality of the CLinkedList" << endl;
	cout << "This is effectively a sequential search of the CLinkedList class" << endl;
	cout << "All searches use the data comparison routine YOU designate" << endl;
	cout << "Looking for node containing >DATA=05<" << endl;
	cout << "(RETURN to continue)";
	getchar();
	cout << endl;
	strcpy(myStructure.Data,"DATA=05");
	cout << endl;
	/*-------------------------------------------------------
	* First we use the dlfind() method
	*------------------------------------------------------*/

	if (pStructure = (Structure *)myList.dlfind(&myStructure))
		cout << "Found >" << pStructure->Data << "< myChar=" << pStructure->myChar
		<< " Position=(" << myList.dlposn() << ")" << endl;
	else    cout << "Couldn't find it!" << endl;

	cout << "We may also use a binary search (obviously quicker) on a sorted list" << endl;
	cout << "In order to find a node.  This time, we use the dlbsearch() method" << endl;
	cout << "Looking for node >DATA=06< with dlbsearch()" << endl;
	
	/*-------------------------------------------------------
	* Now we use the dlbsearch() method (binary search)
	*------------------------------------------------------*/
	
	strcpy(myStructure.Data, "DATA=06");	// Look for a different one this time.
	if (pStructure = (Structure *)myList.dlbsearch(&myStructure))
		cout << "Found >" << pStructure->Data << "< myChar=" << pStructure->myChar
		<< " Position=(" << myList.dlposn() << ")" << endl;
	else    cout << "Couldn't find it!" << endl;
	cout << "Press RETURN to continue";
	getchar();


	// Add another node to the list
	// but populate a "structure" first...
	strcpy(myStructure.Data, "DATA=00");	// Look for a different one this time.
	myStructure.myChar = new char[kSmallBuf];
	assert(myStructure.myChar);
	// print a number into the new space
	sprintf(myStructure.myChar, "%02d", 0);

	// Add it to the list (Use a different method)
	cout << "Adding another node to the list" << endl;
	cout << "Adding Data=>" << myStructure.Data << "< myChar="
		<< myStructure.myChar << endl;

	myList << &myStructure;

	cout << "There are currently " << myList.dlcount() << " nodes in the list" << endl;
	pStructure = (Structure *)myList.dltofirst();
	while (pStructure) {
		cout << ">" << pStructure->Data << "< myChar=" << pStructure->myChar
			<< " Position=(" << myList.dlposn() << ")" << endl;
		pStructure = (Structure *)myList.dlgofwd();
	}
	cout << "Press RETURN to continue";
	getchar();
	cout << "When adding to the list, using the dladd() method appends to the " << endl;
	cout << "end of the list" << endl; // So does the "<<" operator.
	cout << "The List is now NOT correctly sorted, so we try a dlbsearch() on the" << endl;
	cout << "list.  We should now expect a FAIL because a binary search only works on a sorted list." << endl;
	// NOTE: We COULD still find this particular node by sequentially
	//		visiting every element in the list until it's found.  However this
	//		is a test example of binary searching on an unsorted list.

	/*----------------------------------------------------------------------
	* Now we use the dlbsearch() method (binary search) expecting a fail
	*----------------------------------------------------------------------*/
	strcpy(myStructure.Data, "DATA=06");	// Look for a different node this time.
	if (pStructure = (Structure *)myList.dlbsearch(&myStructure))
		cout << "Found >" << pStructure->Data << "< myChar=" << pStructure->myChar
		<< " Position=(" << myList.dlposn() << ")" << endl;
	else {
		cout << "Couldn't find it! - Status = " << myList.GetStatus() << endl;
		cout << "This is the error number >ListHasNotBeenSorted< or" << endl;
	}

	cout << "We now sort the list with dlqsort() and try again" << endl;
	cout << "RETURN to continue and sort" << endl;
	getchar();
	myList.dlqsort();
	cout << endl;

	cout << "List has now been sorted by the qsort() method" << endl;
	cout << "Looking again for DATA=06" << endl;
	cout << "(RETURN to continue)" << endl;
	getchar();

	/*----------------------------------------------------------------------
	* Now we use the dlbsearch() method (binary search) expecting success
	*----------------------------------------------------------------------*/
	if (pStructure = (Structure *)myList.dlbsearch(&myStructure))
		cout << "Found >" << pStructure->Data << "< myChar=" << pStructure->myChar
		<< " Position=(" << myList.dlposn() << ")" << endl;
	else {
		cout << "Couldn't find it! - Status = " << myList.GetStatus() << endl;
	}


	/*----------------------------------------------------------------------
	* Print the contents of the list so the user can believe it
	*----------------------------------------------------------------------*/
	cout << "Printing the list again (forwards)" << endl;
	cout << endl;

	pStructure = (Structure *)myList.dltofirst();
	while (pStructure) {
		cout << ">" << pStructure->Data << "< myChar=" << pStructure->myChar
			<< " Position=(" << myList.dlposn() << ")" << endl;
		pStructure = (Structure *)myList.dlgofwd();
	}
	cout << "Press RETURN to continue" << endl;
	getchar();

	/*----------------------------------------------------------------------
	* Show the user the dlsetcompare() method
	*----------------------------------------------------------------------*/
	cout << "About to CHANGE the comparison function using dlsetcompare()" << endl;
	cout << "sorting will also occur (different comparison function)" << endl;
	myList.dlsetcompare(ReverseStringCompare);
	myList.dlsort();	// Use the primitive swap sort algorithm

	cout << "Finished - About to print list contents (RETURN to continue)";
	getchar();
	cout << endl;

	pStructure = (Structure *)myList.dltofirst();
	while (pStructure) {
		cout << ">" << pStructure->Data << "< myChar=" << pStructure->myChar
			<< " Position=(" << myList.dlposn() << ")" << endl;
		pStructure = (Structure *)myList.dlgofwd();
	}
	cout << "Note how the nodes are now sorted in DESCENDING order" << endl;

	/*-------------------------------------------------------
	*         Now delete the 6th node in the list.
	*------------------------------------------------------*/

	cout << "About to delete NODE 6 (RETURN to continue)" << endl;
	getchar();
	cout << endl;

	if (pStructure = (Structure *)myList.dlfind(&myStructure)) {
		myList.dldelete();
		cout << "DONE!.. about to print list contents" << endl;

		pStructure = (Structure *)myList.dltofirst();
		while (pStructure) {
			cout << ">" << pStructure->Data << "< myChar=" << pStructure->myChar
				<< " Position=(" << myList.dlposn() << ")" << endl;
			pStructure = (Structure *)myList.dlgofwd();
		}
		cout << "There are now " << myList.dlcount() << " nodes in the list" << endl;
	}
	else {
		cout << "Couldn't find the 6th NODE in the list" << endl;
	}
	cout << "(RETURN to continue)";
	getchar();
	cout << endl;


	/*-------------------------------------------------------
	* Now insert a node in the list.  NOTE: If you want to
	* insert a node at the beginning of the list use:
	* dlrewind THEN dlinsert, otherwise just use dlinsert.
	*------------------------------------------------------*/
	cout << "About to insert a NODE at BEGINNING of LIST "
		"(RETURN to continue)" << endl;
	getchar();

	strcpy(myStructure.Data, "NODE=This is the NEWLY dlinserted one!");
	cout << "sizeof(myStructure.Data)=(" << sizeof(myStructure.Data) << ")" << endl;

 	myStructure.myChar = new char[kSmallBuf];
	assert(myStructure.myChar);
	strcpy(myStructure.myChar, "Inserted Number");
	myList.dlrewind();  // Go to beginning of list (remember,there is no currency here)
	myList.dlinsert(&myStructure);  // We now have currency.

	pStructure = (Structure *)myList.dltofirst();
	cout << "\nAfter dlinsert......." << endl;
	while (pStructure) {
		cout << ">" << pStructure->Data << "< myChar=" << pStructure->myChar
			<< " Position=(" << myList.dlposn() << ")" << endl;
		pStructure = (Structure *)myList.dlgofwd();
	}
	cout << "There are now " << myList.dlcount() << " nodes in the list" << endl;
	/*-------------------------------------------------------
	* If you want to delete the nodes in the list, and wish
	* to retain an empty list rather than delete it,
	* then just use the dlclear() function.
	/*-------------------------------------------------------
	* Now test the dlreplace() method.
	*------------------------------------------------------*/
	cout << endl;
	cout << "About to replace <DATA=10> with <DATA=11>" << endl;
	cout << "(RETURN to continue)";
	getchar();

	strcpy(myStructure.Data, "DATA=10");
	cout << "Searching for DATA=10" << endl;
	if (pStructure = (Structure *)myList.dlfind(&myStructure)) {
		cout << "SUCCESSFUL find" << endl;
		// Insert some new data into our STRUCTURE 
		myStructure.myChar = new char[kSmallBuf];
		assert(myStructure.myChar);
		strcpy(myStructure.Data,  "DATA=11");
		strcpy(myStructure.myChar, "Now Number 11"); // New "data"
		myList.dlreplace(&myStructure);
	}
	else {
		cout << "Can't find the node in the list" << endl;
	}
	/*-------------------------------------------------------
	* Print the contents of the list to show that it worked.
	*------------------------------------------------------*/
	pStructure = (Structure *)myList.dltofirst();
	while (pStructure) {
		cout << ">" << pStructure->Data << "< myChar=" << pStructure->myChar
			<< " Position=(" << myList.dlposn() << ")" << endl;
		pStructure = (Structure *)myList.dlgofwd();
	}
	cout << "There are now " << myList.dlcount() << " nodes in the list" << endl;
	cout << "About to test list marking methods (any key to continue)";
	getchar();
	cout << endl;
	/*-------------------------------------------------------
	* 	Now test the list marking facilities.
	*------------------------------------------------------*/
	cout << "As there have been no previously MARKED nodes in the list " << endl;
	cout << "we WILL get an error code of NodeNotPreviouslyMarked returned" << endl;
	if (myList.dltomark()) {
		cout << "ERROR: (expected) Not previously marked!" << endl;
	}	
	// As a node has NOT been marked, we cannot go to said node, so we WILL get an error
	if (myList.dlatmark()) {
		cout << "ERROR: (expected) Node has NOT been marked!" << endl;
	}
	cout << "(RETURN to continue)" << endl;
	getchar();

	/*-------------------------------------------------------
	* Now let's mark the third node in the list.
	*------------------------------------------------------*/
	cout << "About to mark the third node in the list" << endl;
	cout << "(RETURN to continue)";
	getchar();

	// Insert the data KEY we want to look for ...
	strcpy(myStructure.Data, "DATA=03");

	// Remember, dlfind just does a sequential search of each node
	// until it finds (or not) what we're looking for.
	if (pStructure = (Structure *)myList.dlfind(&myStructure)) {
		myList.dlmark();
		cout << "Done. Marked node :" << pStructure->Data << endl;
		cout << "Moving away from marked node: " << endl;
		pStructure = (Structure *)myList.dltolast();	// Move away from marked node
		cout << "Done. now at node (" << myList.dlposn() << ")" << endl;
		cout << "Searching for previously marked node" << endl;
		myList.dltomark();
		if (myList.dlatmark()) {
			cout << "OK, at the marked node" << endl;
			/* Get a fresh copy of the data found */
			pStructure = (Structure *)myList.dlget();
			cout << ">" << pStructure->Data << "< myChar=" << pStructure->myChar
				<< " Position=(" << myList.dlposn() << ")" << endl;
		}
	}
	else {
		cout << "Can't find the third node !!!!" << endl;
	}
	
	cout << "The size of each NODE in the list is(" << myList.GetDataSize() << ") bytes" << endl;

	// Testing some of the other operator overloads
	// THIS FOLLOWS 0th element properties. As defined.
	// In other words,  the 0th element in the list is
	// the first one.

	int nElementNumber = 0;	// The node I want to use in the operand

	cout << "Looking for list element [" << nElementNumber << "]" << endl;
	cout << "(RETURN to continue)" << endl;
	getchar();
	pStructure = (Structure*)myList[nElementNumber];
	if (pStructure) {
		// Print the contents of the node designated.
		cout <<"Found: " <<
			">" << pStructure->Data << "< myChar=" << pStructure->myChar
			<< " Position=(" << myList.dlposn() << ")" << endl;
	}
	else {
		cout << "Could not find element [" << nElementNumber << "]" << endl;
	}
	cout << "About to dump list contents..." << endl;
	cout << "(RETURN to continue)" << endl;
	getchar();
	myList.dldumplist();

	// Now we've finished demonstrating our lists we can
	// delete all the nodes. They still exist in memory.  As the "myList"
	// was declared as a local variable, it will fall out of
	// scope when the function returns but in this example we'll empty
	// the list of all it's nodes first.
	retCode = myList.dlclear();	// List now empty.

	cout << "There are (" << myList.dlcount() << ") nodes in the list" << endl;

	cout << "List test 1 complete ..." << endl;
	cout << endl;
	return( retCode );
}


/******************************************************************************
*  Function Name: int TestListOfIntegers(void)
*
*  Purpose:
*		Demonstrates the CLinkedList class member functions
*		using a simple atomic data type.
*
*  Parameters: None.
*
*  Side Effects:  List of integers are in reverse order.
*
*
*  Notes: This funtion inserts nodes to the beginning (head) of the list.
*
*
******************************************************************************/

int TestListOfIntegers(void)
{
	int retCode = 0;
	int x;

	cout << "Testing atomic data types..." << endl;
	CLinkedList	myIntegerList(sizeof(x), CompareIntegers);
	for (int i = 1; i <= kMaxNodes; i++) {
		// We'll just keep adding to the beginning (head) of the list.
		myIntegerList.dlrewind();
		retCode = myIntegerList.dlinsert(&i);
		if (retCode) {
			cout << "Error (" << retCode << ") adding to list" << endl;
			return (retCode);
		}
	}

	cout << "Nodes in list = (" << myIntegerList.dlcount() << ")" << endl;

	// Print list contents
	int *p = (int *)myIntegerList.dltofirst();
	while (p) {
		cout << "Value = (" << *p << "): posn = (" << myIntegerList.dlposn() << ")" << endl;
		p = (int *)myIntegerList.dlgofwd();
	}
	cout << "List test 2 complete ... <press <ENTER>" << endl;
	myIntegerList.dlclear();
	getchar();

	return (retCode);
}
/******************************************************************************
*  Function Name: double fRand( double, double)
*
*  Purpose:
*		Generates a random double number.
*
*  Parameters: 
*		1.	Minimum double boundary.
*		2.	Maximum double boundary.
*
*  Side Effects:  Returns a small floating point number.
*
*
*  Notes: None.
*
*
******************************************************************************/
double fRand(double fMin, double fMax)
{
	double f = (double)rand() / RAND_MAX;
	double retVal = fMin + f * (fMax - fMin);

	return (f);
}

/******************************************************************************
*  Function Name: int CompareDoubles(void)
*
*  Purpose:
*		Demonstrates CLinkedList class member functions
*		using a double simple double atomic data type.
*
*  Parameters:	 None.
*
*  Side Effects: None.
*
*
*  Notes:	 None.
*
*
******************************************************************************/
int CompareDoubles(const void* d1, const void *d2)
{
	double dbl1 = *(double *)d1;
	double dbl2 = *(double *)d2;
	int retCode = 0;

	if (dbl1 == dbl2)
		retCode = 0;
	else if (dbl1 < dbl2)
		retCode = -1;
	else if (dbl1 > dbl2)
		retCode = 1;
	return (retCode);
}

/******************************************************************************
*  Function Name: int TestListWithDoubles(void)
*
*  Purpose:
*		Demonstrates the CLinkedList class member functions
*		using a simple double atomic data type.
*
*  Parameters: None.
*
*  Side Effects:  List of floating point values are displayed in 
*				ascending order after the list is sorted.
*
*
*  Notes: This funtion uses insertion sorting on adding to list.
*
*
******************************************************************************/

int TestListWithDoubles(void)
{
	int retCode = 0;

	CLinkedList myDoubleList(sizeof(double), CompareDoubles);
	
	// Add some doubles to the list
	for (int i = 0; i < kMaxNodes; i++) {
		// We'll use insertion sorting for this example
		double d = fRand(0, RAND_MAX );	// Generate some small random doubles.

		cout << "Adding (" << d << ") to the list" << endl;
		retCode = myDoubleList.dladdins(&d);
		if (retCode) {
			cout << "Error (" << retCode << ") adding to list" << endl;
			return (retCode);
		}
	}
	cout << "Nodes in list = (" << myDoubleList.dlcount() << ")" << endl;

	getchar();

	cout << "Printing list of doubles AFTER insertion sorting..." << endl;
	double *p = (double *)myDoubleList.dltofirst();
	while (p) {
		cout << "Value = (" << *p << "): posn = (" << myDoubleList.dlposn() << ")" << endl;
		p = (double *)myDoubleList.dlgofwd();
	}
	cout << "List test 3 complete ... <press <ENTER>" << endl;
	
	getchar();
	return (retCode);
}
		

// Entry point for the program.
int main(int argc, char* argv[])
{
	int retCode = 0;

	// to get different random numbers every run
	srand(static_cast<unsigned int>(time(NULL)));
	retCode = TestLinkedListRoutinesWithStructures();
	if (retCode == 0)
		retCode = TestListOfIntegers();
	if (retCode == 0)
		retCode = TestListWithDoubles();

	return ( retCode );
}

